#define LINUX_PACKAGE_ID " Kali 6.12.38-1kali1"
