#define UTS_RELEASE "6.12.38+kali-amd64"
